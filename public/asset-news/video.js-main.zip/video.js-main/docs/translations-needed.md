# Translations needed

The currently available translations are in the lang dir. This table shows the completeness of those translations. Anything not listed does not exist yet, so go ahead and create it by copying `en.json`.

If you add or update a translation run `npm run docs:lang` to update the list and include this modified doc in the pull request.

## Progress Bar Translations

The progress bar has a translation with a few token replacements.
They key is `progress bar timing: currentTime={1} duration={2}` and the default English value is `{1} of {2}`.
This default value is hardcoded as a default to the localize method in the SeekBar component.

## Status of translations

<!-- START langtable -->

| Language file           | Missing translations                                                                |
| ----------------------- | ----------------------------------------------------------------------------------- |
| ar.json (missing 3)     | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| ba.json (missing 63)    | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Replay                                                                              |
|                         | Seek to live, currently behind live                                                 |
|                         | Seek to live, currently playing live                                                |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Descriptions                                                                        |
|                         | descriptions off                                                                    |
|                         | Audio Track                                                                         |
|                         | Volume Level                                                                        |
|                         | The media is encrypted and we do not have the keys to decrypt it.                   |
|                         | Play Video                                                                          |
|                         | Close                                                                               |
|                         | Close Modal Dialog                                                                  |
|                         | Modal Window                                                                        |
|                         | This is a modal window                                                              |
|                         | This modal can be closed by pressing the Escape key or activating the close button. |
|                         | , opens captions settings dialog                                                    |
|                         | , opens subtitles settings dialog                                                   |
|                         | , opens descriptions settings dialog                                                |
|                         | , selected                                                                          |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
|                         | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| bg.json (missing 63)    | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Replay                                                                              |
|                         | Seek to live, currently behind live                                                 |
|                         | Seek to live, currently playing live                                                |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Descriptions                                                                        |
|                         | descriptions off                                                                    |
|                         | Audio Track                                                                         |
|                         | Volume Level                                                                        |
|                         | The media is encrypted and we do not have the keys to decrypt it.                   |
|                         | Play Video                                                                          |
|                         | Close                                                                               |
|                         | Close Modal Dialog                                                                  |
|                         | Modal Window                                                                        |
|                         | This is a modal window                                                              |
|                         | This modal can be closed by pressing the Escape key or activating the close button. |
|                         | , opens captions settings dialog                                                    |
|                         | , opens subtitles settings dialog                                                   |
|                         | , opens descriptions settings dialog                                                |
|                         | , selected                                                                          |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
|                         | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| ca.json (missing 63)    | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Replay                                                                              |
|                         | Seek to live, currently behind live                                                 |
|                         | Seek to live, currently playing live                                                |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Descriptions                                                                        |
|                         | descriptions off                                                                    |
|                         | Audio Track                                                                         |
|                         | Volume Level                                                                        |
|                         | The media is encrypted and we do not have the keys to decrypt it.                   |
|                         | Play Video                                                                          |
|                         | Close                                                                               |
|                         | Close Modal Dialog                                                                  |
|                         | Modal Window                                                                        |
|                         | This is a modal window                                                              |
|                         | This modal can be closed by pressing the Escape key or activating the close button. |
|                         | , opens captions settings dialog                                                    |
|                         | , opens subtitles settings dialog                                                   |
|                         | , opens descriptions settings dialog                                                |
|                         | , selected                                                                          |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
|                         | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| cs.json (missing 4)     | Seek to live, currently behind live                                                 |
|                         | Seek to live, currently playing live                                                |
|                         | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| cy.json (missing 4)     | Seek to live, currently behind live                                                 |
|                         | Seek to live, currently playing live                                                |
|                         | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| da.json (missing 63)    | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Replay                                                                              |
|                         | Seek to live, currently behind live                                                 |
|                         | Seek to live, currently playing live                                                |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Descriptions                                                                        |
|                         | descriptions off                                                                    |
|                         | Audio Track                                                                         |
|                         | Volume Level                                                                        |
|                         | The media is encrypted and we do not have the keys to decrypt it.                   |
|                         | Play Video                                                                          |
|                         | Close                                                                               |
|                         | Close Modal Dialog                                                                  |
|                         | Modal Window                                                                        |
|                         | This is a modal window                                                              |
|                         | This modal can be closed by pressing the Escape key or activating the close button. |
|                         | , opens captions settings dialog                                                    |
|                         | , opens subtitles settings dialog                                                   |
|                         | , opens descriptions settings dialog                                                |
|                         | , selected                                                                          |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
|                         | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| de.json (missing 2)     | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| el.json (missing 49)    | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Replay                                                                              |
|                         | Seek to live, currently behind live                                                 |
|                         | Seek to live, currently playing live                                                |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Volume Level                                                                        |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
|                         | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| es.json (missing 2)     | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| fa.json (Complete)      |                                                                                     |
| fi.json (missing 63)    | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Replay                                                                              |
|                         | Seek to live, currently behind live                                                 |
|                         | Seek to live, currently playing live                                                |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Descriptions                                                                        |
|                         | descriptions off                                                                    |
|                         | Audio Track                                                                         |
|                         | Volume Level                                                                        |
|                         | The media is encrypted and we do not have the keys to decrypt it.                   |
|                         | Play Video                                                                          |
|                         | Close                                                                               |
|                         | Close Modal Dialog                                                                  |
|                         | Modal Window                                                                        |
|                         | This is a modal window                                                              |
|                         | This modal can be closed by pressing the Escape key or activating the close button. |
|                         | , opens captions settings dialog                                                    |
|                         | , opens subtitles settings dialog                                                   |
|                         | , opens descriptions settings dialog                                                |
|                         | , selected                                                                          |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
|                         | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| fr.json (missing 5)     | Seek to live, currently behind live                                                 |
|                         | Seek to live, currently playing live                                                |
|                         | {1} is loading.                                                                     |
|                         | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| gd.json (missing 2)     | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| gl.json (missing 2)     | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| he.json (missing 5)     | Seek to live, currently behind live                                                 |
|                         | Seek to live, currently playing live                                                |
|                         | {1} is loading.                                                                     |
|                         | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| hr.json (missing 63)    | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Replay                                                                              |
|                         | Seek to live, currently behind live                                                 |
|                         | Seek to live, currently playing live                                                |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Descriptions                                                                        |
|                         | descriptions off                                                                    |
|                         | Audio Track                                                                         |
|                         | Volume Level                                                                        |
|                         | The media is encrypted and we do not have the keys to decrypt it.                   |
|                         | Play Video                                                                          |
|                         | Close                                                                               |
|                         | Close Modal Dialog                                                                  |
|                         | Modal Window                                                                        |
|                         | This is a modal window                                                              |
|                         | This modal can be closed by pressing the Escape key or activating the close button. |
|                         | , opens captions settings dialog                                                    |
|                         | , opens subtitles settings dialog                                                   |
|                         | , opens descriptions settings dialog                                                |
|                         | , selected                                                                          |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
|                         | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| hu.json (missing 63)    | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Replay                                                                              |
|                         | Seek to live, currently behind live                                                 |
|                         | Seek to live, currently playing live                                                |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Descriptions                                                                        |
|                         | descriptions off                                                                    |
|                         | Audio Track                                                                         |
|                         | Volume Level                                                                        |
|                         | The media is encrypted and we do not have the keys to decrypt it.                   |
|                         | Play Video                                                                          |
|                         | Close                                                                               |
|                         | Close Modal Dialog                                                                  |
|                         | Modal Window                                                                        |
|                         | This is a modal window                                                              |
|                         | This modal can be closed by pressing the Escape key or activating the close button. |
|                         | , opens captions settings dialog                                                    |
|                         | , opens subtitles settings dialog                                                   |
|                         | , opens descriptions settings dialog                                                |
|                         | , selected                                                                          |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
|                         | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| it.json (missing 63)    | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Replay                                                                              |
|                         | Seek to live, currently behind live                                                 |
|                         | Seek to live, currently playing live                                                |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Descriptions                                                                        |
|                         | descriptions off                                                                    |
|                         | Audio Track                                                                         |
|                         | Volume Level                                                                        |
|                         | The media is encrypted and we do not have the keys to decrypt it.                   |
|                         | Play Video                                                                          |
|                         | Close                                                                               |
|                         | Close Modal Dialog                                                                  |
|                         | Modal Window                                                                        |
|                         | This is a modal window                                                              |
|                         | This modal can be closed by pressing the Escape key or activating the close button. |
|                         | , opens captions settings dialog                                                    |
|                         | , opens subtitles settings dialog                                                   |
|                         | , opens descriptions settings dialog                                                |
|                         | , selected                                                                          |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
|                         | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| ja.json (missing 63)    | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Replay                                                                              |
|                         | Seek to live, currently behind live                                                 |
|                         | Seek to live, currently playing live                                                |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Descriptions                                                                        |
|                         | descriptions off                                                                    |
|                         | Audio Track                                                                         |
|                         | Volume Level                                                                        |
|                         | The media is encrypted and we do not have the keys to decrypt it.                   |
|                         | Play Video                                                                          |
|                         | Close                                                                               |
|                         | Close Modal Dialog                                                                  |
|                         | Modal Window                                                                        |
|                         | This is a modal window                                                              |
|                         | This modal can be closed by pressing the Escape key or activating the close button. |
|                         | , opens captions settings dialog                                                    |
|                         | , opens subtitles settings dialog                                                   |
|                         | , opens descriptions settings dialog                                                |
|                         | , selected                                                                          |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
|                         | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| ko.json (missing 63)    | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Replay                                                                              |
|                         | Seek to live, currently behind live                                                 |
|                         | Seek to live, currently playing live                                                |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Descriptions                                                                        |
|                         | descriptions off                                                                    |
|                         | Audio Track                                                                         |
|                         | Volume Level                                                                        |
|                         | The media is encrypted and we do not have the keys to decrypt it.                   |
|                         | Play Video                                                                          |
|                         | Close                                                                               |
|                         | Close Modal Dialog                                                                  |
|                         | Modal Window                                                                        |
|                         | This is a modal window                                                              |
|                         | This modal can be closed by pressing the Escape key or activating the close button. |
|                         | , opens captions settings dialog                                                    |
|                         | , opens subtitles settings dialog                                                   |
|                         | , opens descriptions settings dialog                                                |
|                         | , selected                                                                          |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
|                         | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| nb.json (missing 2)     | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| nl.json (missing 5)     | Seek to live, currently behind live                                                 |
|                         | Seek to live, currently playing live                                                |
|                         | {1} is loading.                                                                     |
|                         | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| nn.json (missing 2)     | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| oc.json (missing 2)     | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| pl.json (missing 55)    | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Replay                                                                              |
|                         | Seek to live, currently behind live                                                 |
|                         | Seek to live, currently playing live                                                |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Descriptions                                                                        |
|                         | descriptions off                                                                    |
|                         | Audio Track                                                                         |
|                         | Volume Level                                                                        |
|                         | The media is encrypted and we do not have the keys to decrypt it.                   |
|                         | Close Modal Dialog                                                                  |
|                         | , opens descriptions settings dialog                                                |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
|                         | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| pt-BR.json (missing 4)  | Seek to live, currently behind live                                                 |
|                         | Seek to live, currently playing live                                                |
|                         | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| pt-PT.json (missing 48) | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Seek to live, currently behind live                                                 |
|                         | Seek to live, currently playing live                                                |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Volume Level                                                                        |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
|                         | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| ru.json (missing 4)     | Seek to live, currently behind live                                                 |
|                         | Seek to live, currently playing live                                                |
|                         | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| sk.json (missing 4)     | Seek to live, currently behind live                                                 |
|                         | Seek to live, currently playing live                                                |
|                         | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| sr.json (missing 63)    | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Replay                                                                              |
|                         | Seek to live, currently behind live                                                 |
|                         | Seek to live, currently playing live                                                |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Descriptions                                                                        |
|                         | descriptions off                                                                    |
|                         | Audio Track                                                                         |
|                         | Volume Level                                                                        |
|                         | The media is encrypted and we do not have the keys to decrypt it.                   |
|                         | Play Video                                                                          |
|                         | Close                                                                               |
|                         | Close Modal Dialog                                                                  |
|                         | Modal Window                                                                        |
|                         | This is a modal window                                                              |
|                         | This modal can be closed by pressing the Escape key or activating the close button. |
|                         | , opens captions settings dialog                                                    |
|                         | , opens subtitles settings dialog                                                   |
|                         | , opens descriptions settings dialog                                                |
|                         | , selected                                                                          |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
|                         | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| sv.json (missing 2)     | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| tr.json (missing 13)    | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Seek to live, currently behind live                                                 |
|                         | Seek to live, currently playing live                                                |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Volume Level                                                                        |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
|                         | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| uk.json (missing 4)     | Seek to live, currently behind live                                                 |
|                         | Seek to live, currently playing live                                                |
|                         | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| vi.json (missing 5)     | Seek to live, currently behind live                                                 |
|                         | Seek to live, currently playing live                                                |
|                         | {1} is loading.                                                                     |
|                         | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| zh-CN.json (missing 2)  | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |
| zh-TW.json (missing 2)  | Exit Picture-in-Picture                                                             |
|                         | Picture-in-Picture                                                                  |

<!-- END langtable -->
